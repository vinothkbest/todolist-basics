<?php
session_start();

if (isset($_SESSION['mail'])) : ?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="./assets/lib/bootstrap.min.css">
<script type="text/javascript" src="./assets/lib/jquery.min.js"></script>
<script type="text/javascript" src="./assets/lib/bootstrap.min.js"></script>
<script src="./assets/lib/datepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="./assets/lib/datepicker.min.css">
<link rel="stylesheet" type="text/css" href="./assets/style.css">
<script type="text/javascript" src="./assets/read.js"></script>
</head>
<body>
	<div class="container logout-panel">
		<a href="./model/logout.php" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-log-out"></span> Log out
        </a>
	</div>	
	<div class="container form-panel" style="margin-top : 50px;">
			
		<form class="taskfill" method="post" action="">
			<input type="text" name="project" placeholder="Project Name" autocomplete="off"  required>
			<input type="text" name="client" placeholder="Client Name" autocomplete="off"  required>
			<input type="text" id="datepicker" name="due" placeholder="Last Date [YYY-MM-DD]" autocomplete="off"  required>
			<select name="status">
				<option value="Yet to Start">Yet to Start</option>
				<option value="In Progress">In Progress</option>
				<option value="Completed">Completed</option>
				<option value="Near to Complete">Near to Complete</option>
			</select>
			<input type="submit" name="assign" Value='Assign Task'>
		</form>
	</div>

	<div class="container response-panel" style="margin-top : 50px;">

		<div class="response-task" style="margin-top : 20px;">
			
		</div>
		<div class="response-list" style="margin-top : 20px;">

			<table></table>
			
		</div>
		
	</div>
</body>
</html>		
	

<?php else : 

	header("location:login.php");

endif;


?>

 <script>



  $( function() {

    $( "#datepicker" ).datepicker({

		format: 'yyyy-mm-dd',

    });

	
  } );
  </script>