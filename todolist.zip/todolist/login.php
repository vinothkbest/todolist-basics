<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>login</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="./assets/lib/bootstrap.min.css">
<script type="text/javascript" src="./assets/lib/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="./assets/style.css">
<link rel="stylesheet" type="text/css" href="./assets/date.css">
<script type="text/javascript" src='./assets/verify.js'></script>
</head>
<body>
	<div class="container">
		<form action="./model/verify.php" method="post" id="log01">
		<input type="text" name="email" id='log01-email' placeholder="Enter Email" autocomplete="off">
		<input type="password" name="password" id='log01-pwd' placeholder="Enter Emp Password" autocomplete="off">
		<input type="submit" name="login">
		<a href="./home.php"><input type="button" value="<< No Account?"></a>
	</form>
	<div class="verify"></div>
	</div>

</body>
</html>


