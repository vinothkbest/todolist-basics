$('table').remove();
$('.response-list').append('<table/>');

var th, tr;
tr = $('<tr/>');
tr.append("<th>Project Title</th>");
tr.append("<th>Client Name</th>");
tr.append("<th>Start Date</th>");
tr.append("<th>End Date</th>");
tr.append("<th>Status</th>");
$('table').append(tr);

for (var i = 1; i < tasks.length; i++){
	tr = $('<tr/>');
	tr.append("<td>" + tasks[i][0] + "</td>");
	tr.append("<td>" + tasks[i][1] + "</td>");
	tr.append("<td>" + tasks[i][2] + "</td>");
	tr.append("<td>" + tasks[i][3] + "</td>");
	if (tasks[i][4] == 'In Progress') {

		tr.append("<td class='inprogress'>" + tasks[i][4] + "</td>");
		$('table').append(tr);
	}
	else if(tasks[i][4] == 'Completed'){

		tr.append("<td class='completed'>" + tasks[i][4] + "</td>");
		$('table').append(tr);
	}
	else if(tasks[i][4] == 'Yet to Start'){

		tr.append("<td class='yts'>" + tasks[i][4] + "</td>");
		$('table').append(tr);
	}
	else if(tasks[i][4] == 'Near to Complete'){

		tr.append("<td class='ntc'>" + tasks[i][4] + "</td>");
		$('table').append(tr);
	}
}