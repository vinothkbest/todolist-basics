$(document).ready(function(){

//verfy File

$('#log01').on('submit', function(){

		var data = $('#log01').serialize();

		console.log(data);

		$.ajax({
		url : './model/verify.php',
		type : 'post',
		data : data,
		cache: false,

		success : function(response){

			console.log(response.trim());

				if(response.trim() !== 'verified'){

					$('.verify').text(response.trim());	

				}

				else {
					
					location.href = './todolist.php';
				}

			},
		});	

	return false;
	});
	
});

