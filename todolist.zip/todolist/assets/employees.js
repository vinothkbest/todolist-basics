$(document).ready(function(){

//Write File
$('#reg01').on('submit', function(){

		var data = $('#reg01').serialize();

		console.log(data);

		$.ajax({
		url : './model/employees.php',
		type : 'post',
		data : data,
		cache: false,

		success : function(response){

				$('.response').text(response.trim());	

			},
		});	

	return false;
	});
	
});

