<?php 

	
	$result = mysqli_query($conf,$select);

	$data = mysqli_fetch_assoc($result);

	

 ?>