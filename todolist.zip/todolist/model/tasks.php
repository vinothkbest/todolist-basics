<?php
session_start();

	include './classes/tasklist.php';

    $Tasklist = new Tasklist(trim($_POST['project']), trim($_POST['client']), trim($_POST['due']), trim($_POST['status']));

	echo($Tasklist->taskassign($_SESSION));
?>