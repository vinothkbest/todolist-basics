<?php

class Employees{
	
	public static function creation($name, $email, $department, $password){

		require_once './config.php';
	 	
		$name = mysqli_real_escape_string($conf, $name);
		
		$Email = mysqli_real_escape_string($conf, $email);
		
		$department = mysqli_real_escape_string($conf, $department);

		$password = password_hash(mysqli_real_escape_string($conf, $password), PASSWORD_DEFAULT);

		

		$reg = "CALL PutEmpDetails('$name', '$Email', '$department', '$password')";

		return (mysqli_query($conf,$reg)) ? 'Data registered' : 'Not Stored';		 
		
	}

}

?>
