<?php
class EmpLogin {

	protected $email;
	protected $password;

	public function __construct($email, $password)
	{
		
		$this->email = $email;
		$this->password = $password;
		

	}

	public function verify(){

			require_once './config.php';

			$Empemail = mysqli_real_escape_string($conf, $this->email);
			
			$password = mysqli_real_escape_string($conf, $this->password);

			$sql = "SELECT * FROM `Emp_Registration` WHERE Emp_Email = '$Empemail'";

			$result = mysqli_query($conf,$sql);

			$data = mysqli_fetch_assoc($result);

			if(password_verify($password, $data['Emp_Password'])) :

				return 'verified';

			else : return "not verified! Please chech your credentials!";				

			endif;		
			
	}

}

?>
