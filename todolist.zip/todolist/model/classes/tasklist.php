<?php
class Tasklist{

	public $Project_Title;
	public $Client_Name;
	public $Due_Time;
	public $Status;

	public function __construct($project, $client, $due, $status)
	{
		
		$this->Project_Title = $project;
		$this->Client_Name = $client;
		$this->Due_Time = $due;
		$this->Status = $status;

		

	}

	public function taskassign($array){

			
			require_once './config.php';


			$proj = mysqli_real_escape_string($conf, $this->Project_Title);
			
			$cleint = mysqli_real_escape_string($conf, $this->Client_Name);
			
			$last = mysqli_real_escape_string($conf, $this->Due_Time);
			
			$status = mysqli_real_escape_string($conf, $this->Status);

			$mail = $array["mail"];

			$select = "SELECT * FROM `Emp_Registration` WHERE Emp_Email = '$mail'";

			require('./auto_query.php');

			$task_id = mt_rand(1000, 9999);

			$EmpID = trim($data["Emp_Id"]);

		
			$exec = "CALL AssignTask('$EmpID', '$task_id', '$proj', '$cleint', '$last', '$status')";
			
			(mysqli_query($conf,$exec)) ? $list = ['task assigned!'] : $list = ['task not assigned!'];

			//$exec = "CALL AssignTask('$EmpID', '$task_id', 'ekobe', 'MSC', '2020-12-30', 'yet to start')";

			$select = "SELECT * FROM `Task_Details` WHERE Emp_ID = '$EmpID'";
			
			$result = mysqli_query($conf,$select);

			while($data = mysqli_fetch_assoc($result)) :

				array_push($list, array($data['Project_Title'], $data['Client_Name'], $data['Start_Time'], $data['Due_Time'], $data['Status']));


			endwhile;

			return json_encode($list);


	}

	

}

?>
