<?php

	include './classes/employees.php';

	echo Employees::creation($_POST['Empname'], $_POST['Email'], $_POST['Empdept'], $_POST['Emppassword']);


?>