<?php		

$conf = mysqli_connect('localhost', 'root', 'Ninos@2018', 'TodoList');

/*
CREATE DATABASE TodoList;

create TABLE Emp_Registration (Emp_Id int AUTO_INCREMENT NOT NULL, 
                               Emp_Name varchar(255) NOT NULL,
                               Emp_Email varchar(255) NOT NULL UNIQUE KEY, 											   Emp_Department varchar(255) NOT NULL,
                               Emp_Password varchar(255),
                               CONSTRAINT pk_emp PRIMARY KEY(Emp_id)); 
                                    
ALTER TABLE Emp_Registration AUTO_INCREMENT = 100;


CREATE TABLE Task_Details (Emp_Id int NOT NULL, Task_Id int NOT NULL, Project_Title varchar(255) NOT NULL UNIQUE KEY, 
                           Client_Name varchar(255) NOT NULL, Start_Time varchar(255) NOT NULL, Due_Time varchar(255) NOT NULL,
                           Status varchar(255) NOT NULL,
                           CONSTRAINT pk_task PRIMARY KEY(Emp_Id, Task_Id),
                           CONSTRAINT fk_task FOREIGN KEY(Emp_Id) REFERENCES Emp_Registration(Emp_Id) ON UPDATE CASCADE ON DELETE CASCADE);
                                    

use TodoList;

DELIMITER //

CREATE PROCEDURE PutEmpDetails(IN name varchar(255), IN Email varchar(255), IN Dept varchar(255), IN pswd varchar(255))
BEGIN
	INSERT INTO Emp_Registration (`Emp_Name`, `Emp_Email`, `Emp_Department`, `Emp_Password`) VALUES (name,Email, Dept,pswd);
    
END //

DELIMITER ;


CALL PutEmpDetails('Emp2', 'HR', '$$emp2$$');



DELIMITER //

CREATE PROCEDURE AssignTask (IN empid int, IN proj_id int,
                             IN project varchar(255),
                             IN client varchar(255),
                             IN due date,
                             IN proj_status varchar(255))

BEGIN

DECLARE Start_date date;

SET Start_date =  CURRENT_DATE();

INSERT INTO `Task_details`(`Emp_Id`, `Task_Id`, `Project_Title`, `Client_Name`, `Start_Time`, `Due_Time`, `Status`) VALUES (empid, proj_id, project, client, Start_date, due, proj_status);

 
END //

DELIMITER ;

CALL AssignTask(100, 'kerney bank', 'MSC', '2020-12-10', 'yet to start'); 

*/
?>


