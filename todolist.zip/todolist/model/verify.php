<?php
session_start();

	include './classes/verify.php';


	$_SESSION['mail'] = $_POST['email'];

	$EmpLogin = new EmpLogin($_POST['email'], $_POST['password']);


	echo $EmpLogin->verify();


?>
