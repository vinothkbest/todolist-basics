<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
</head>
<link rel="stylesheet" type="text/css" href="./assets/lib/bootstrap.min.css">
<script type="text/javascript" src="./assets/lib/jquery.min.js"></script>
<script type="text/javascript" src="./assets/employees.js"></script>
<link rel="stylesheet" type="text/css" href="./assets/style.css">
<body>
	<div class="container">
		<form action="" method="post" id="reg01">
			<input type="text" name="Empname" id='reg01-name' placeholder="Enter Name" autocomplete="off" required>
			<input type="text" name="Email" id='reg01-email' placeholder="Enter Email or User Name" autocomplete="off" required>
			<input type="text" name="Empdept" id='reg01-dept' placeholder="Enter Department" autocomplete="off" required>
			<input type="password" name="Emppassword" id='reg01-pwd' placeholder="Enter Password" autocomplete="off" required>
			<input type="submit" name="submit">
		</form>
		<div class="others">
			<a href="./login.php"><button>If already Registered?</button></a>
			<div class="response"></div>
		</div>
	</div>
</body>
</html>

